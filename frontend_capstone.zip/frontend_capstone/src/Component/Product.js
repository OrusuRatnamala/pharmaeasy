import React from "react";
import Navbaradmin from "./Navbaradmin";
import Table from 'react-bootstrap/Table';
function Product() {
    return (
        <div>
            <Navbaradmin/>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Product_Id</th>
            <th>Product_Name</th>
            <th>Manufacture_Date</th>
            <th>Expiry_Date</th>
            <th>Price</th>
            <th>Quantity</th>
           
           
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>Aspirin</td>
            <td>10-11-1999</td>
            <td>1-11-2023</td>
            <td>20</td>
            <td>500</td>
          </tr>
          <tr>
            <td>2</td>
            <td>Dolo</td>
            <td>10-11-1990</td>
            <td>1-11-2021</td>
            <td>21</td>
            <td>510</td>
          </tr>
          <tr>
          <td>3</td>
            <td>Paracetamol</td>
            <td>2-11-1890</td>
            <td>1-11-2020</td>
            <td>23</td>
            <td>510</td>
          </tr>
        </tbody>
      </Table>
         
      </div>
    );
  }
 
  export default Product;