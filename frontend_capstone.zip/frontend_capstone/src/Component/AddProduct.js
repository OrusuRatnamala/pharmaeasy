import React, { useState } from 'react';
import axios from 'axios';
import Navbaradmin from "./Navbaradmin";
import "./AddProduct.css";
import { useNavigate } from "react-router-dom";
 
function AddProduct() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    productid: '',
    pname: '',
    manufacturedate: '',
    expirydate: '',
    price: '',
    quantity: '',
    stock: ''
  });
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };
 
  const handleSubmit = async () => {
    try {
      const response = await axios.post('http://localhost:8080/save', formData);
 
      if (response.status === 200) {
        console.log('Product added successfully');
        navigate("/VendorAccount");
      } else {
        console.error('Failed to add product');
      }
    } catch (error) {
      console.error('Error during product addition:', error);
    }
  };
 
  return (
 
    <div>
      <Navbaradmin />
      <div >
        <img
          src="addproduct.jpg"
          alt="Product Image"
          className="w-100 h-100 object-cover rounded-md"
        />
     
      <div>
  <div className='absolute top-1/4 left-1/5 transform -translate-y-1/3 translate-x-1/3 w-90 h-10'>
    <div className="bg-gray-100 p-4 border-6 rounded-md shadow-md ">
      <h1 className="text-lg font-bold mb-4">Add Product</h1>
      <form onSubmit={handleSubmit} className="flex flex-col items-left form-inline">
        <div className="flex flex-wrap w-80 h-50 ">
          <div className="w-1/4 md:w-1/2 lg:w-1/3 p-2">
            <label className="mb-2 text-sm font-normal font-serif">Product ID</label>
            <input type="text" name="productid" onChange={handleChange} className="w-full border p-1 rounded mb-4" />
          </div>
          <div className="w-1/4 md:w-1/2 lg:w-1/3 p-2">
            <label className="mb-2 text-sm font-normal font-serif">Product Name</label>
            <input type="text" name="pname" onChange={handleChange} className="w-full border p-1 rounded mb-4" />
          </div>
          <div className="w-1/4 md:w-1/2 lg:w-1/3 p-2">
            <label className="mb-2 text-sm font-normal font-serif">Stock</label>
            <input type="text" name="stock" onChange={handleChange} className="w-full border p-1 rounded mb-4" />
          </div>
          <div className="w-1/4 md:w-1/2 lg:w-1/3 p-2">
            <label className="mb-2 text-sm font-normal font-serif">Expiry Date</label>
            <input type="date" name="expirydate" onChange={handleChange} className="w-full border p-1 rounded mb-4" />
          </div>
          <div className="w-1/4 md:w-1/2 lg:w-1/3 p-2">
            <label className="mb-2 text-sm font-normal font-serif">Price</label>
            <input type="text" name="price" onChange={handleChange} className="w-full border p-1 rounded mb-4" />
          </div>
          <div className="w-1/4 md:w-1/2 lg:w-1/3 p-2">
            <label className="mb-2 text-sm font-normal font-serif">Quantity</label>
            <input type="text" name="quantity" onChange={handleChange} className="w-full border p-1 rounded mb-4" />
          </div>
          <div className="w-1/4 md:w-1/2 lg:w-1/3 p-2">
            <label className="mb-2 text-sm font-normal font-serif">Manufacture Date</label>
            <input type="date" name="manufacturedate" onChange={handleChange} className="w-full border p-1 rounded mb-4" />
          </div>
         
        </div>
        <button type="button" onClick={handleSubmit} className="w-full bg-blue-500 text-white p-1 rounded cursor-pointer">
          Submit
        </button>
      </form>
    </div>
  </div>
</div>
 
        </div>
      </div>
      );
}
 
      export default AddProduct;