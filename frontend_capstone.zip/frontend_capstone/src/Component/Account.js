import React from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "./Navbar";
 
function Account() {
  const navigate = useNavigate(); // Initialize the useNavigate hook
 
  const handleLogoutClick = () => {
    // Add your logout logic here
    console.log("User logged out!");
 
    // Redirect to the root route (landing page)
    navigate("/");
  };
 
  return (
    <div>
      <Navbar />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <div className="bg-white p-4 rounded-md shadow-md">
          <img
            src="https://png.pngtree.com/png-vector/20191125/ourmid/pngtree-beautiful-admin-roles-line-vector-icon-png-image_2035379.jpg"
            alt="Product 1"
            className="w-full h-30 object-cover mb-4 rounded-md"
          />
          <h3 className="text-xl font-semibold mb-2">Customer</h3>
          <p className="text-gray-700 mb-4">Customer Details</p>
          <p className="text-blue-500 font-semibold">Customer Id</p><p>000001</p><br/>
          <p className="text-blue-500 font-semibold">Address</p><p>East Street, Vizag</p><br/>
          <p className="text-blue-500 font-semibold">Phone Number</p><p>9139883988</p><br/>
        </div>
      </div>
 
      {/* Log Out Button below the Admin grid card */}
      <div className="flex justify-start mt-4">
        <button
          onClick={handleLogoutClick}
          className="bg-blue-500 text-white px-4 py-2 rounded-md"
        >
          Log Out
        </button>
      </div>
    </div>
  );
}
 
export default Account;